# GitHub Actions Workflows for AmiBroker Web

This directory contains the GitHub Actions workflows for automated deployment and data ingestion:

1. **`deploy.yml`**:
   - Automatically builds and deploys the AmiBroker Web app to **GitHub Pages** whenever you push to `main` or `master`.
   - Also supports 1-click manual deployment via `workflow_dispatch`.

2. **`daily_nse_bhavcopy_r2.yml`**:
   - Automated NSE Bhavcopy & Deliverable Data Ingestion pipeline.
   - Runs automatically every Monday–Friday at 19:00 IST (13:30 UTC).
   - Allows manual on-demand execution for single day or range backfill (e.g., 2026-01-01 to 2026-10-03).
   - Uploads compressed bundles to Cloudflare R2 (`data/eod_latest.json.gz`, `data/history_latest.json.gz`, `data/symbols.json`).

3. **`daily_bse_bhavcopy_r2.yml`**:
   - Automated BSE Bhavcopy ingestion pipeline for 3,500+ listed scrips.
   - Runs independently every Monday–Friday at 19:30 IST (14:00 UTC).
   - Merges seamlessly into unified catalog without overwriting NSE data.

---

### Where should these files be placed in your GitHub repository?
GitHub Actions requires workflow files to be located in:
```
.github/workflows/
```
Because operating systems (Windows and macOS) hide folders that start with a dot (`.`), they are also copied here in `github-workflows/` for your convenience.

To activate these workflows on GitHub:
1. In your GitHub repository, ensure you have the `.github/workflows/` folder.
2. Place `deploy.yml`, `daily_nse_bhavcopy_r2.yml`, and `daily_bse_bhavcopy_r2.yml` inside `.github/workflows/`.
3. Add your Cloudflare R2 secrets in GitHub Repository **Settings -> Secrets and variables -> Actions**:
   - `R2_ACCOUNT_ID`
   - `R2_ACCESS_KEY_ID`
   - `R2_SECRET_ACCESS_KEY`
   - `R2_BUCKET_NAME`
4. For GitHub Pages deployment: Go to **Settings -> Pages** -> set **Source** to **GitHub Actions**.
